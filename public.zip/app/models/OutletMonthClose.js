
import mongoose from "mongoose";

const FounderBalanceSchema = new mongoose.Schema(
  {
    founder: {
      type: String,
      required: true,
      enum: ["Mayank", "Krishna"],
    },
    capitalOutstandingPaise: {
      type: Number,
      default: 0,
      min: 0,
    },
    loanOutstandingPaise: {
      type: Number,
      default: 0,
      min: 0,
    },
  },
  { _id: false }
);

const AccountBalancesSchema = new mongoose.Schema(
  {
    cashPaise: {
      type: Number,
      default: 0,
      min: 0,
      validate: Number.isSafeInteger,
    },
    bankPaise: {
      type: Number,
      default: 0,
      min: 0,
      validate: Number.isSafeInteger,
    },
    silverGrams: {
      type: Number,
      default: 0,
      min: 0,
    },
  },
  { _id: false }
);

const ProfitSchema = new mongoose.Schema(
  {
    netSalesPaise: { type: Number, default: 0 },
    operatingMarginPaise: { type: Number, default: 0 },
    confirmedSilverAdjustmentPaise: { type: Number, default: 0 },
    provisionalSilverAdjustmentPaise: { type: Number, default: 0 },
    operatingExpensesPaise: { type: Number, default: 0 },
    setupCostsPaise: { type: Number, default: 0 },
    confirmedRealProfitPaise: { type: Number, default: 0 },
    estimatedRealProfitPaise: { type: Number, default: 0 },
  },
  { _id: false }
);

const OutletMonthCloseSchema = new mongoose.Schema(
  {
    monthKey: {
      type: String,
      required: true,
      unique: true,
      match: /^\d{4}-(0[1-9]|1[0-2])$/,
      index: true,
    },

    opening: {
      type: AccountBalancesSchema,
      required: true,
    },

    closing: {
      type: AccountBalancesSchema,
      required: true,
    },

    profit: {
      type: ProfitSchema,
      default: () => ({}),
    },

    founders: {
      type: [FounderBalanceSchema],
      default: [],
    },

    physicalCashCountPaise: {
      type: Number,
      default: null,
      min: 0,
    },

    physicalSilverCountGrams: {
      type: Number,
      default: null,
      min: 0,
    },

    cashDifferencePaise: {
      type: Number,
      default: null,
    },

    silverDifferenceGrams: {
      type: Number,
      default: null,
    },

    status: {
      type: String,
      enum: ["draft", "closed", "reopened"],
      default: "draft",
      index: true,
    },

    notes: {
      type: String,
      default: "",
      maxlength: 2000,
    },

    closedAt: {
      type: Date,
      default: null,
    },

    closedBy: {
      type: String,
      default: "",
    },

    previousMonthCloseId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "OutletMonthClose",
      default: null,
    },
  },
  { timestamps: true }
);

export default mongoose.models.OutletMonthClose ||
  mongoose.model("OutletMonthClose", OutletMonthCloseSchema);
